<!doctype html>
<html lang="pt-br">

<head>
  <!-- META TAGS -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="keywords" content="<?= self::prepareMetadata(MenuComponent::activePage())->keywords;?>">
  <meta name="description" content="<?= self::prepareMetadata(MenuComponent::activePage())->description; ?>">
  <meta name="author" content="">

  <link rel="icon" href="<?= BASE_URL; ?>favicon.ico">
  <!-- TITLE -->
  <title><?= $this->viewTitle($tit) ?></title>

  <!-- Principal CSS do Bootstrap -->
  <link href="<?= BASE_URL; ?>assets/css/bootstrap/bootstrap.min.css" rel="stylesheet">
  <!-- DataTables -->
  <link href="<?= BASE_URL; ?>assets/css/dataTables/datatables.min.css" rel="stylesheet">
  <!-- SWAL -->
  <link href="<?= BASE_URL; ?>assets/css/swal/sweetalert2.min.css" rel="stylesheet">
  <!-- Personal Styles -->
  <link href="<?= BASE_URL; ?>assets/css/personal/style.css" rel="stylesheet">

  <!-- FONTES -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="<?= BASE_URL; ?>assets/fonts/?family=Volkolak:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>

<body id="page-top">

  <!--  ================================================================================================== -->
  <!-- Navigation bar -->
  <section role="main" class="bg-petroleum text-center pt-5 pb-5 mb-5" id="main">
    <a href="<?= BASE_URL; ?>">
      <img src="<?= BASE_URL; ?>assets/imgs/logo.png" class="img-fluid" width="300px" alt="Model Car Racing">
    </a>
  </section>

  <? #= MetaDataComponent::showMetaDataFromDB();

  use Core\Controller;

  ?>

  <nav class="navbar navbar-expand-lg" id="navbarNav">
    <div class="container">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="effect"></div>
      <div class="collapse navbar-collapse navbar-custom jump-over">
        <ul class="navbar-nav">
          <!-- Menu -->
          <?php foreach (\MenuComponent::showMenuFromDB() as $key => $val): ?>
            <li class="nav-item ml-0 font-weight-bold">
              <a class="nav-link <?= \MenuComponent::activePage() == $val->slug ? 'active-menu' : ''; ?>" href="<?= BASE_URL . $val->slug; ?>">
                <?= $val->slug; ?>
              </a>
            </li>
          <?php endforeach; ?>
          <!-- / Menu -->
        </ul>
      </div>
  </nav>

  <!-- Content -->
  <main role="main">
    <!-- MAIN CONTENT -->
    <?php self::loadViewInTemplate($viewName, $viewData); ?>
    <!-- MAIN CONTENT -->
  </main>

  <!--  ================================================================================================== -->

  <!-- Bootstrap JavaScript
  ================================================== -->
  <!-- Foi colocado no final para a página carregar mais rápido -->
  <script src="<?= BASE_URL; ?>assets/js/jquery/jquery_3.7.1_min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="<?= BASE_URL; ?>assets/js/bootstrap/bootstrap.min.js"></script>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script src="<?= BASE_URL; ?>assets/js/dataTables/datatables.min.js"></script>
  <script src="<?= BASE_URL; ?>assets/js/swal/sweetalert2.all.min.js"></script>
  <script src="<?= BASE_URL; ?>assets/js/jquery/jquery.maskMoney.min.js" type="text/javascript"></script>
  <script src="<?= BASE_URL; ?>assets/js/jquery/jquery.mask.js" type="text/javascript"></script>
  <!-- <script src="<? // BASE_URL; 
                    ?>assets/js/tpl-scripts.js" type="text/javascript"></script> -->
  <script src="<?= BASE_URL; ?>assets/js/scripts.js" type="text/javascript"></script>

</body>

</html>