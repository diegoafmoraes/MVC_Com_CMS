<!-- Header Image -->
<section class="main-section">
    <div class="header-image" id="cover_lil_car">
        <!--     <img src="<?= BASE_URL; ?>assets/imgs/cover_lil_car.png" class="img-fluid" alt="Model Car Racing"> -->

        <div class="container-fluid mt-5">

            <section class="container text-section">

                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="https://cdn.pixabay.com/photo/2023/05/20/16/54/rose-8006847_640.jpg" alt="First slide">
                        </div>
                    </div>

                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </section>


        </div>

        <!-- Banner Advertising Space (agora sobrepostos à imagem do carro) -->
        <div class="container text-center banner-container-rel">
            <div class="row">
                <div class="col-12 col-md-4">
                    <div class="banner red">Banner Advertising Space<br>70 x 450 px</div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="banner yellow">Banner Advertising Space<br>70 x 450 px</div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="banner green">Banner Advertising Space<br>70 x 450 px</div>
                </div>
            </div>
        </div>
    </div>

</section>