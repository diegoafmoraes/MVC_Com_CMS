# modeloCRUD
Modelo de CRUD baseado no curso PHP B7WEB
